<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Interview;
use Faker\Generator as Faker;

$factory->define(Interview::class, function (Faker $faker) {
    return [
        //
    ];
});
