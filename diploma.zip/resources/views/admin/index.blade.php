@extends('adminlte::page')

@section('title', 'Админ панель')

@section('content_header')
    <h1>Административная Панель</h1>
@stop

@section('content')
    <p>Добро пожаловать!</p>
@stop

