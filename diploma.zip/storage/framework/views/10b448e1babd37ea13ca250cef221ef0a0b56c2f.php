

<?php $__env->startSection('title', 'Новости'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Новости
      <a href="/admin/news/create" class="btn btn-primary btn-sm">Добавить новость</a>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <table class="table">
    	<thead>
    		<tr>
    			<th>#</th>
    			<th>Изображение</th>
    			<th>Название</th>
    			<th>Slug</th>
    			<th>Содержание</th>
    			<th></th>
    		</tr>
    	</thead>
    	<tbody>
    		<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		<tr>
    			<td><?php echo e($loop->iteration); ?></td>
    			<td><img src="<?php echo e($item->img); ?>" alt="<?php echo e($item->name); ?>" style="width:100px"></td>
    			<td><?php echo e($item->name); ?></td>
    			<td><?php echo e($item->slug); ?></td>
    			<td><?php echo e($item->description); ?></td>
    			<td>
                    <a href="/admin/news/<?php echo e($item->id); ?>/edit" class="btn btn-warning">
                    
                    <i class="fa fa-edit"></i>
                    
                </a>
                <form action="/admin/news/<?php echo e($item->id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    
                    <?php echo method_field('DELETE'); ?>
                    
                    <button class="btn btn-danger"><i class="fa fa-trash"></i></button>

                </form>
           



                </td>
    		</tr>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</tbody>
    </table>
    <div class ="mt-5 d-flex justify-content-center">
    <?php echo e($news->links()); ?> 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\OSPanel\domains\diploma\resources\views/admin/news/index.blade.php ENDPATH**/ ?>