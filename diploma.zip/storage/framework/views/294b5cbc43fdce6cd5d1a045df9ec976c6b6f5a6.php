
<?php $__env->startSection('title', 'Оформление заказа -'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	
<h1>Оформление заказа</h1>

	<div class="modal-body">
		<?php echo $__env->make('buy._cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>

<?php if(auth()->guard()->guest()): ?>
<p><a href="<?php echo e(route('login')); ?>">Войдите</a> или <a href="<?php echo e(route('register')); ?>">Зарегистрируйтесь</a></p>
<?php else: ?>
<?php if(session('cart')): ?>
<a href="/end-checkout" class="btn btn-primary">Завершить оформление заказа</a>
</div>
<?php endif; ?>

<?php endif; ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\OSPanel\domains\diploma\resources\views/buy/checkout.blade.php ENDPATH**/ ?>