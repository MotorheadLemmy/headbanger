
<?php $__env->startSection('title', 'Результаты поиска -'); ?>
<?php $__env->startSection('content'); ?>
<h2 class="text-center mb-5">Результаты поиска <?php echo e(Request::input('query')); ?>:</h2>
<div class="container">
	<?php if(!$news->count() && !$reviews->count() && !$interviews->count() && !$shirts->count()): ?>
	<p>Ничего не найдено</p>
	<?php else: ?>
	<div class="row">
	<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $onenews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="col-12">
      <div>
        	<h3 class="text-center mb-3 mt-3"><?php echo e($onenews->name); ?></h3><br>
        	<?php if($onenews->img): ?>
        	<img src="<?php echo e($onenews->img); ?>" alt="<?php echo e($onenews->name); ?>" class="float-left mr-3" style="width:30%">
        	<?php endif; ?>
        	<p><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e(date('d.m.Y H:i', strtotime($onenews->created_at))); ?>  <i class="fa fa-commenting-o" aria-hidden="true"></i>  Комментариев:<?php echo e($onenews->comments->count()); ?></p>
        	<p><?php echo \Str::words($onenews->description, 40); ?>

        	<a href="/news/<?php echo e($onenews->slug); ?>">Читать далее</a>

        </div>
        

    </div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="col-12">
      <div>
        	<h3 class="text-center mb-3 mt-3"><?php echo e($review->band); ?></h3><br>
            <h4 class="text-center mb-5"><?php echo e($review->album); ?></h4>
        	<?php if($review->img): ?>
        	<img src="<?php echo e($review->img); ?>" alt="<?php echo e($review->band); ?>" class="float-left mr-3" style="width:30%">
        	<?php endif; ?>
        	<p><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e(date('d.m.Y H:i', strtotime($review->created_at))); ?> <i class="fa fa-commenting-o" aria-hidden="true"></i>  Комментариев:<?php echo e($review->comments->count()); ?></p>
        	<p><?php echo \Str::words($review->description, 40); ?>

        	<a href="/reviews/<?php echo e($review->slug); ?>">Читать далее</a>
        </div>
    </div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php $__currentLoopData = $interviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interview): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	
	<div class="col-12">
      <div>
        	<h3 class="text-center mb-3 mt-3"><?php echo e($interview->name); ?></h3><br>
        	<?php if($interview->img): ?>
        	<img src="<?php echo e($interview->img); ?>" alt="<?php echo e($interview->name); ?>" class="float-left mr-3" style="width:30%">
        	<?php endif; ?>
        	<p><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e(date('d.m.Y H:i', strtotime($interview->created_at))); ?> <i class="fa fa-commenting-o" aria-hidden="true"></i> Комментариев:<?php echo e($interview->comments->count()); ?></p>
        	<p><?php echo \Str::words($interview->description, 80); ?>

        	<a href="/interviews/<?php echo e($interview->slug); ?>">Читать далее</a>
        </div>
    </div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    <?php $__currentLoopData = $shirts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shirt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	
		<div>
			<br>
			<div class="row my-5">
			<div class="col-4">


		<a href="/buy/<?php echo e($shirt->slug); ?>" class="linkshirt"><img src="<?php echo e($shirt->img); ?>" alt="<?php echo e($shirt->name); ?>" class="mr-3" style="width:80%"><br>
	
      </div>

  <div class="col-8">
  	<h3 class="text-center mb-3 mt-3"><?php echo e($shirt->name); ?></h3>
			
			
			<em><b><?php echo e($shirt->description); ?></b></em><br>
			<span class="priceshirt"> Цена:<br>
	€ <?php echo e($shirt->price); ?></a><br></span>
	
		</div>
		</div>
	</div>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>	
	</div>
	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\OSPanel\domains\diploma\resources\views/search/results.blade.php ENDPATH**/ ?>