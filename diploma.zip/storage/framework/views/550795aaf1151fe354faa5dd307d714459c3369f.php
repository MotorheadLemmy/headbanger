<h1> Новый заказ #<?php echo e($order->id); ?></h1>
User:<?php echo e($order->user->name); ?><br>
TotalSum:<?php echo e($order->total_sum); ?>

<hr>

<table class="table">
	<thead>
		<tr>
			<th>Img</th>
			<th>Name</th>
			<th>Price</th>
			<th>Size</th>
			<th>Qty</th>
			<th>Summa</th>
		</tr>
	</thead>
	<tbody>
		<?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shirt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><img src="<?php echo e(env('APP_URL')); ?>/<?php echo e($shirt['img']); ?>" alt="" style="width:70px"></td>
			<td><?php echo e($shirt['name']); ?></td>
			<td><?php echo e($shirt['price']); ?></td>
			<td><?php echo e($shirt['size']); ?></td>
			<td><?php echo e($shirt['qty']); ?></td>
			<td><?php echo e($shirt['price']*$shirt['qty']); ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
	
</table><?php /**PATH C:\Users\Admin\Desktop\OSPanel\domains\diploma\resources\views/email/order.blade.php ENDPATH**/ ?>