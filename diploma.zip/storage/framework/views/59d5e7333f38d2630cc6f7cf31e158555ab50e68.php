
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
    <div class="row">
        <div class="col-sm">

<h2 class="text-center mb-5 news"> Новости</h2>
	
	<h2 class="text-center mb-5"><?php echo e($news->name); ?></h2>

 
    <?php if($news->img): ?>
            <img src="<?php echo e($news->img); ?>" alt="<?php echo e($news->name); ?>" class="float-left mr-3 mb-3" style="width:42%">
            <?php endif; ?>

            <p><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e(date('d.m.Y H:i', strtotime($news->created_at))); ?>  </p>
    <p><?php echo \Str::words($news->description, 90); ?>

        	<a href="/news/<?php echo e($news->slug); ?>">Читать далее</a></p>
        </div>


	
<div class="col-sm">

<h2 class="text-center mb-5 news">Рецензии</h2>

<h2 class="text-center mb-5"><?php echo e($review->band); ?></h2>
<h4 class="text-center mb-5"><?php echo e($review->album); ?></h4>

 
    <?php if($review->img): ?>
            <img src="<?php echo e($review->img); ?>" alt="<?php echo e($review->band); ?>" class="float-left mr-3 mb-3" style="width:45%">
            <?php endif; ?>
            <p><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e(date('d.m.Y H:i', strtotime($review->created_at))); ?></p>
    <p><?php echo \Str::words($review->description, 90); ?>

    	<a href="/reviews/<?php echo e($review->slug); ?>">Читать далее</a></p>
    </div>
   
<div class="col-sm">

	<h2 class="text-center mb-5 news">Интервью</h2>
	<h2 class="text-center mb-5"><?php echo e($interview->name); ?></h2>

 
    <?php if($interview->img): ?>
            <img src="<?php echo e($interview->img); ?>" alt="<?php echo e($interview->name); ?>" class="float-left mr-3 mb-3" style="width:46%">
            <?php endif; ?>

            <p> <i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e(date('d.m.Y H:i', strtotime($interview->created_at))); ?>  </p>
    <p><?php echo \Str::words($interview->description, 80); ?>

            
        	<a href="/interviews/<?php echo e($interview->slug); ?>">Читать далее</a></p>
</div>
</div>
</div>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\OSPanel\domains\diploma\resources\views/main/index.blade.php ENDPATH**/ ?>