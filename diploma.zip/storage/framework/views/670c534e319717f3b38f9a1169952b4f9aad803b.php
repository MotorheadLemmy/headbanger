

<?php $__env->startSection('title', 'Рецензии'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Рецензии
    	<a href="/admin/review/create" class="btn btn-primary btn-sm">Добавить рецензию</a>

    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<table class="table">
    	<thead>
    		<tr>
    			<th>#</th>
    			<th>Изображение</th>
    			<th>Группа</th>
    			<th>Альбом</th>
    			<th>Slug</th>
    			<th>Трэклист</th>
    			<th>Рецензия</th>
    			<th>Оценка</th>
    			<th></th>
    		</tr>
    	</thead>
    	<tbody>
    		<?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		<tr>
    			<td><?php echo e($loop->iteration); ?></td>
    			<td><img src="<?php echo e($review->img); ?>" alt="<?php echo e($review->name); ?>" style="width:100px"></td>
    			<td><?php echo e($review->band); ?></td>
    			<td><?php echo e($review->album); ?></td>
    			<td><?php echo e($review->slug); ?></td>
    			<td><?php echo e($review->tracklist); ?></td>
    			<td><?php echo e($review->description); ?></td>
    			<td><?php echo e($review->rating); ?></td>
    			<td>
                    <a href="/admin/review/<?php echo e($review->id); ?>/edit" class="btn btn-warning">
                    
                    <i class="fa fa-edit"></i>
                    
                </a>
                <form action="/admin/review/<?php echo e($review->id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    
                    <?php echo method_field('DELETE'); ?>
                    
                    <button class="btn btn-danger"><i class="fa fa-trash"></i></button>

                </form>

                </td>
    		</tr>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</tbody>
    </table>
    <div class ="mt-5 d-flex justify-content-center">
    <?php echo e($reviews->links()); ?> 
</div>
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\OSPanel\domains\diploma\resources\views/admin/review/index.blade.php ENDPATH**/ ?>