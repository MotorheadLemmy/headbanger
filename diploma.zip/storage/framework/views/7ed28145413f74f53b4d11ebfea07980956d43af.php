

<?php $__env->startSection('title', 'Футболки'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Футболки
    	<a href="/admin/shirt/create" class="btn btn-primary btn-sm">Добавить футболку</a>

    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<table class="table">
    	<thead>
    		<tr>
    			<th>#</th>
    			<th>Изображение 1</th>
                <th>Изображение 2</th>
                <th>Изображение 3</th>
    			<th>Название</th>
    			<th>Slug</th>
    			<th>Описание</th>
    			<th>Цена</th>
    			<th></th>
    		</tr>
    	</thead>
    	<tbody>
    		<?php $__currentLoopData = $shirts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shirt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		<tr>
    			<td><?php echo e($loop->iteration); ?></td>
    			<td><img src="<?php echo e($shirt->img); ?>" alt="<?php echo e($shirt->name); ?>" style="width:50px"></td>
                <td><img src="<?php echo e($shirt->img1 ?? '/images/no.png'); ?>" alt="<?php echo e($shirt->name); ?>" style="width:50px"></td>
                <td><img src="<?php echo e($shirt->img2 ?? '/images/no.png'); ?>" alt="<?php echo e($shirt->name); ?>" style="width:50px"></td>
    			<td><?php echo e($shirt->name); ?></td>
    			<td><?php echo e($shirt->slug); ?></td>
    			<td><?php echo e($shirt->description); ?></td>
    			<td><?php echo e($shirt->price); ?></td>
    			<td>
                    <a href="/admin/shirt/<?php echo e($shirt->id); ?>/edit" class="btn btn-warning">
                    
                    <i class="fa fa-edit"></i>
                    
                </a>
                <form action="/admin/shirt/<?php echo e($shirt->id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    
                    <?php echo method_field('DELETE'); ?>
                    
                    <button class="btn btn-danger"><i class="fa fa-trash"></i></button>

                </form>
           



                </td>
    		</tr>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</tbody>
    </table>
    
<div class ="mt-5 d-flex justify-content-center">
    <?php echo e($shirts->links()); ?> 
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\OSPanel\domains\diploma\resources\views/admin/shirt/index.blade.php ENDPATH**/ ?>