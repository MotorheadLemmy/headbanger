
<?php $__env->startSection('title', 'Новости -'); ?>
<?php $__env->startSection('content'); ?>
<h2 class="text-center news">Новости</h2>
<div class="container">
  <div class="row">
    
    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-12">
      <div>
        	<h3 class="text-center mb-3 mt-3"><?php echo e($item->name); ?></h3><br>
        	<?php if($item->img): ?>
        	<img src="<?php echo e($item->img); ?>" alt="<?php echo e($item->name); ?>" class="float-left mr-3" style="width:30%">
        	<?php endif; ?>
        	<p><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e(date('d.m.Y H:i', strtotime($item->created_at))); ?>  <i class="fa fa-commenting-o" aria-hidden="true"></i>  Комментариев:<?php echo e($item->comments->count()); ?></p>
        	<p><?php echo \Str::words($item->description, 40); ?>

        	<a href="/news/<?php echo e($item->slug); ?>">Читать далее</a>

        </div>
        

    </div>

        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
    <div class ="mt-5 d-flex justify-content-center">
    <?php echo e($news->links()); ?> 
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\OSPanel\domains\diploma\resources\views/news/news.blade.php ENDPATH**/ ?>