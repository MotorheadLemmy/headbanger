

<?php $__env->startSection('title', 'Edit News'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Edit News <?php echo e($news->name); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="/admin/news/<?php echo e($news->id); ?>" method="POST" enctype="multipart/form-data">
	<?php echo method_field('PUT'); ?>
	<?php echo $__env->make('admin.news._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\OSPanel\domains\diploma\resources\views/admin/news/edit.blade.php ENDPATH**/ ?>