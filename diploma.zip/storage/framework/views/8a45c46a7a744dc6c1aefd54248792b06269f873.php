
<?php $__env->startSection('title', 'Контакты -'); ?>
<?php $__env->startSection('content'); ?>
<h2 class="text-center my-3 news">Наши контакты</h2>

<div class="container">

	<p><b> Вы можете найти нас по адресу г.Запорожье,улица Мира 16 или пишите нам на почту headbanger@gmail.com</b></p>
	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2677.5547994731855!2d35.119234215162216!3d47.84821757924966!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40dc672eb9172f79%3A0xb7f55167def4a865!2z0YPQuy4g0JzQuNGA0LAsIDE2LCDQl9Cw0L_QvtGA0L7QttGM0LUsINCX0LDQv9C-0YDQvtC20YHQutCw0Y8g0L7QsdC70LDRgdGC0YwsIDY5MDAw!5e0!3m2!1sru!2sua!4v1599824058018!5m2!1sru!2sua" width="325" height="400" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe><br><br>
	<div class="text-center">
	<p class="text-center"><b>Мы в социальных сетях:</b></p>
	 <div class="wrapper">
   <a target="_blank" href="#"><i class="fa fa-3x fa-instagram"></i></a>
   <a target="_blank" href="#"><i class="fa fa-3x fa-facebook-square"></i></a>
   <a target="_blank" href="#"><i class="fa fa-3x fa-twitter-square"></i>
</div></a>
</div>
	


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\OSPanel\domains\diploma\resources\views/contacts/contacts.blade.php ENDPATH**/ ?>