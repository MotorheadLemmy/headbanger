<div class="jumbotron">
	<div class="container">
		<h1>Привет всем на нашем сайте!</h1>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. 
		</p>
	</div>
</div><?php /**PATH C:\Users\Admin\Desktop\OSPanel\domains\diploma\resources\views/hello.blade.php ENDPATH**/ ?>