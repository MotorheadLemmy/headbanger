
<?php $__env->startSection('title', 'Купить -'); ?>
<?php $__env->startSection('content'); ?>
<h2 class="text-center my-3 news">Доступные футболки</h2><br>
<div class="container">
	<div class="row">
	<?php $__currentLoopData = $shirts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shirt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="col-3 my-3">
	<a href="/buy/<?php echo e($shirt->slug); ?>"><img src="<?php echo e($shirt->img); ?>" alt="<?php echo e($shirt->name); ?>" class="mr-3" style="width:60%"><br>
	Цена:<br>
	€<?php echo e($shirt->price); ?></a><br>
	<em><b><?php echo e($shirt->name); ?></b></em>
	
</div>



	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

	</div>


<?php $__env->stopSection(); ?>
   



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\OSPanel\domains\diploma\resources\views/buy/shirts.blade.php ENDPATH**/ ?>