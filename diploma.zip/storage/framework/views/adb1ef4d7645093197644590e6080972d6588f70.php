
<?php $__env->startSection('title', 'Интервью -'); ?>
<?php $__env->startSection('content'); ?>
<h2 class="text-center mb-5"><?php echo e($interview->name); ?></h2>
<div class="container">
 
    <?php if($interview->img): ?>
            <img src="<?php echo e($interview->img); ?>" alt="<?php echo e($interview->name); ?>" class="float-left mr-3 mb-3" style="width:40%">
            <?php endif; ?>

            <p><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e(date('d.m.Y H:i', strtotime($interview->created_at))); ?> <i class="fa fa-commenting-o" aria-hidden="true"></i>  Комментариев:<?php echo e($interview->comments->count()); ?> </p>
    <p><?php echo $interview->description; ?></p>


      <?php if(auth()->guard()->guest()): ?>
    <h5>Для того чтобы добавить комментарий
    <a href="<?php echo e(route('login')); ?>"> войдите</a>  или <a href="<?php echo e(route('register')); ?>">зарегистрируйтесь</a></h5>
    <?php else: ?>
    <h5>Добавить комментарий:</h5>

    <form action="/interview/<?php echo e($interview->slug); ?>" method="POST">
    	<?php echo csrf_field(); ?>
    	<div class="form-group">
    	<textarea name="comment" cols="20" rows="3" class="form-control">
    		
    	</textarea>
    	</div>
    	<input type="hidden" name="interview" value="<?php echo e($interview->id); ?>">
    	<input type="hidden" name="user" value="<?php echo e(Auth::user()->id); ?>">
    	<button class="btn btn-primary">Отправить</button>
    	

    </form>
    <?php endif; ?>
     <?php $__currentLoopData = $interview->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="my-3 bordercomment">

          
        <span class="commenttext"> <?php echo e($comment->review); ?></span> <br>
          <b><?php echo e($comment->user->name); ?></b> <br>
          <?php echo e($comment->created_at); ?> <br>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




</div>


    



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\OSPanel\domains\diploma\resources\views/interviews/interview.blade.php ENDPATH**/ ?>