
<?php $__env->startSection('title', 'Рецензии -'); ?>
<?php $__env->startSection('content'); ?>
<h2 class="text-center news">Рецензии</h2>
<div class="container">
  <div class="row">
    
    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-12">
      <div>
        	<h3 class="text-center mb-3 mt-3"><?php echo e($review->band); ?></h3><br>
            <h4 class="text-center mb-5"><?php echo e($review->album); ?></h4>
        	<?php if($review->img): ?>
        	<img src="<?php echo e($review->img); ?>" alt="<?php echo e($review->band); ?>" class="float-left mr-3" style="width:30%">
        	<?php endif; ?>
        	<p><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e(date('d.m.Y H:i', strtotime($review->created_at))); ?> <i class="fa fa-commenting-o" aria-hidden="true"></i>  Комментариев:<?php echo e($review->comments->count()); ?></p>
        	<p><?php echo \Str::words($review->description, 40); ?>

        	<a href="/reviews/<?php echo e($review->slug); ?>">Читать далее</a>
        </div>
    </div>
        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class ="mt-5 d-flex justify-content-center">
    <?php echo e($reviews->links()); ?> 
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\OSPanel\domains\diploma\resources\views/reviews/reviews.blade.php ENDPATH**/ ?>