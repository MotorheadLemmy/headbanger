<?php if(session('cart')): ?>
<div class="table-responsive">
<table class="table">
	<thead>
		<tr>
			<th>Фото</th>
			<th>Название</th>
			<th>Цена</th>
			<th>Размер</th>
			<th>Количество</th>
			<th>Сумма</th>
			<th></th>
		</tr>
	</thead>
	<tbody>
		<?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shirt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><img src="<?php echo e($shirt['img']); ?>" alt="" style="width:70px"></td>
			<td><?php echo e($shirt['name']); ?></td>
			<td><?php echo e($shirt['price']); ?> €</td>
			<td><?php echo e($shirt['size']); ?></td>
			<td><?php echo e($shirt['qty']); ?></td>
			<td><?php echo e($shirt['price']*$shirt['qty']); ?> €</td>
			<td>
				<form class="shirt-delete">
					<?php echo csrf_field(); ?>
					<input type="hidden" name="shirt_id" value="<?php echo e($shirt['id']); ?>">
					<input type="hidden" name="size" value="<?php echo e($shirt['size']); ?>">
					<button class="btn btn-danger">Удалить</button>
				</form>
				
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
	<tfoot>
		<tr>
			<td colspan="4" class="text-right">Общая сумма</td>
			<td colspan="2"><?php echo e(session('totalSum')); ?> €</td>

		</tr>
	</tfoot>
</table>
</div>
<input type="hidden" class="count-in-cart" value="<?php echo e(array_sum(array_column(session('cart'), 'qty'))); ?>">
<?php else: ?>
Ваша корзина пуста
<?php endif; ?><?php /**PATH C:\Users\Admin\Desktop\OSPanel\domains\diploma\resources\views/buy/_cart.blade.php ENDPATH**/ ?>