<div class="jumbotron">
	<div class="container">
		
		<h1>Всем Привет!</h1>
		
		<p class="hi">На нашем сайте вы можете ознакомиться с последними новостями мира металла,прочитать рецензии на альбомы и интервью известных исполнителей,а также купить интересующий Вас мерч.
		</p>
	
	</div>
</div><?php /**PATH C:\Users\Admin\Desktop\OSPanel\domains\diploma\resources\views/main/hello.blade.php ENDPATH**/ ?>