

<?php $__env->startSection('title', 'Админ панель'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Административная Панель</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>Добро пожаловать!</p>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\OSPanel\domains\diploma\resources\views/admin/index.blade.php ENDPATH**/ ?>