
<?php $__env->startSection('title', 'Купить -'); ?>
<?php $__env->startSection('content'); ?>
<h2 class="text-center mb-5"><?php echo e($shirt->name); ?></h2>

<div class="container">
	<div class="row">
		<div class="col-6">
				<div class="zoom-img my-3">
					<img src="<?php echo e($shirt->img); ?>" alt="<?php echo e($shirt->name); ?>" class="image minimized" data-big='<?php echo e($shirt->img); ?>'>
				</div>



				<?php if($shirt->img1): ?>
				
					<img src="<?php echo e($shirt->img1); ?>" alt="<?php echo e($shirt->name); ?>" class="mr-3 image minimized" style="width:20%">

				 <?php endif; ?>
				 <?php if($shirt->img2): ?>
					<img src="<?php echo e($shirt->img2); ?>" alt="<?php echo e($shirt->name); ?>" class="mr-3 image minimized" style="width:20%">
					
				 <?php endif; ?>

		</div>
		<div class="col-6">
			
			<span class="priceshirt">Цена:<br>
			€ <?php echo e($shirt->price); ?></span><br>
			<em><b><?php echo e($shirt->description); ?></b></em>


			<form action="/" class="add-to-cart">
				<?php echo csrf_field(); ?>
			   <p><b>Выберите размер футболки</b></p>
			    <p><input name="size" type="radio" value="S">S</p>
			    <p><input name="size" type="radio" value="M">M</p>
			    <p><input name="size" type="radio" value="L" checked>L</p>
			    <p><input name="size" type="radio" value="XL">XL</p>
				
				<input type="number" name="qty" value="1">
				<input type="hidden" name="shirt_id" value="<?php echo e($shirt->id); ?>">
				<button class="btn btn-primary">Добавить в корзину</button>
			</form>
		</div>
	</div>





</div>









<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\OSPanel\domains\diploma\resources\views/buy/shirt.blade.php ENDPATH**/ ?>