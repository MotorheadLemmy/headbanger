

<?php $__env->startSection('title', 'Редактировать комментарий'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Редактировать комментарий <?php echo e($comment->review); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="/admin/comment/<?php echo e($comment->id); ?>" method="POST" enctype="multipart/form-data">
	<?php echo method_field('PUT'); ?>
	
    	<?php echo csrf_field(); ?>
    	<div class="form-group">
    	<textarea name="review" cols="20" rows="3" class="form-control"><?php echo e(old('review',$comment->review ?? '')); ?>

    		
    	</textarea>
    	</div>
    	<input type="hidden" name="comment" value="<?php echo e($comment->id); ?>">
    	<input type="hidden" name="user" value="<?php echo e(Auth::user()->id); ?>">
    	<button class="btn btn-primary">Отправить</button>
    	

    

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\OSPanel\domains\diploma\resources\views/admin/comment/edit.blade.php ENDPATH**/ ?>