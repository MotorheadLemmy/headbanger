
<?php $__env->startSection('title', 'Интервью-'); ?>
<?php $__env->startSection('content'); ?>
<h2 class="text-center news">Интервью</h2>
<div class="container">
  <div class="row">
    
    <?php $__currentLoopData = $interviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interview): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-12">
      <div>
        	<h3 class="text-center mb-3 mt-3"><?php echo e($interview->name); ?></h3><br>
        	<?php if($interview->img): ?>
        	<img src="<?php echo e($interview->img); ?>" alt="<?php echo e($interview->name); ?>" class="float-left mr-3" style="width:30%">
        	<?php endif; ?>
        	<p><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e(date('d.m.Y H:i', strtotime($interview->created_at))); ?> <i class="fa fa-commenting-o" aria-hidden="true"></i> Комментариев:<?php echo e($interview->comments->count()); ?></p>
        	<p><?php echo \Str::words($interview->description, 80); ?>

        	<a href="/interviews/<?php echo e($interview->slug); ?>">Читать далее</a>
        </div>
    </div>
        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class ="mt-5 d-flex justify-content-center">
    <?php echo e($interviews->links()); ?> 
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\OSPanel\domains\diploma\resources\views/interviews/interviews.blade.php ENDPATH**/ ?>