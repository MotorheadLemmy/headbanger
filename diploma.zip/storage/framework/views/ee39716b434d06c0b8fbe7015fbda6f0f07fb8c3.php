

<?php $__env->startSection('title', 'Добавить новость'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Добавить новость</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="/admin/news" method="POST" enctype="multipart/form-data">
	<?php echo $__env->make('admin.news._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

	<script src="//cdn.ckeditor.com/4.6.2/standard/ckeditor.js"></script>	
	<script>
  var options = {
    filebrowserImageBrowseUrl: '/laravel-filemanager?type=Images',
    filebrowserImageUploadUrl: '/laravel-filemanager/upload?type=Images&_token=',
    filebrowserBrowseUrl: '/laravel-filemanager?type=Files',
    filebrowserUploadUrl: '/laravel-filemanager/upload?type=Files&_token='
  };
</script>

	<script>
		CKEDITOR.replace('description', options);
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\OSPanel\domains\diploma\resources\views/admin/news/create.blade.php ENDPATH**/ ?>