  <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="my-3 border mt-5">
          
         <?php echo e($comment->review); ?> <br>
          <?php echo e($comment->user->name); ?> <br>
          <?php echo e($comment->created_at); ?> <br>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Users\Admin\Desktop\OSPanel\domains\diploma\resources\views/comments/_comments.blade.php ENDPATH**/ ?>